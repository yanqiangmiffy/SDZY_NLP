#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author  : humeng
# @Time    : 2021/11/26


# 我们在可迭代IterText中的__iter__返回迭代器IteratorText实例，然而使用生成器的方式会使代码更加优雅
# 因为yield存在于__iter__，因此__iter__变成了生成器函数，调用它则返回一个生成器，同时生成器又实现了迭代器协议，因此IterText满足了可迭代的需求。
class IterText:
    def __init__(self, text):
        self.text = text

    def __iter__(self):
        for letter in self.text:
            yield letter


# Python3.3新增加了yield from关键字，解决了yield的嵌套循环,
def chain(*iterable):
    for it in iterable:
        for i in it:
            yield i


for i in chain('abcd'):
    print(i)
