import math
import torch
import torch.nn as nn


def gelu(x):
    return 0.5 * x * (1 + torch.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * torch.pow(x, 3))))


# linear,LayerNorm,残差
class PositionwiseFeedForward(nn.Module):
    """ A two-layer Feed-Forward-Network with residual layer norm.

    Args:
        d_model (int): the size of input for the first-layer of the FFN.
        d_ff (int): the hidden layer size of the second-layer
            of the FNN.
        dropout (float): dropout probability in :math:`[0, 1)`.
    """

    def __init__(self, d_model, d_ff, dropout=0.1):
        super(PositionwiseFeedForward, self).__init__()
        self.w_1 = nn.Linear(d_model, d_ff)
        self.w_2 = nn.Linear(d_ff, d_model)
        self.layer_norm = nn.LayerNorm(d_model, eps=1e-6)
        self.actv = gelu
        self.dropout_1 = nn.Dropout(dropout)
        self.dropout_2 = nn.Dropout(dropout)

    def forward(self, x):
        inter = self.dropout_1(self.actv(self.w_1(self.layer_norm(x))))
        output = self.dropout_2(self.w_2(inter))
        return output + x


class MultiHeadedAttention(nn.Module):
    """
    Multi-Head Attention module from
    "Attention is All You Need"
    :cite:`DBLP:journals/corr/VaswaniSPUJGKP17`.

    Similar to standard `dot` attention but uses
    multiple attention distributions simulataneously
    to select relevant items.

    Args:
       head_count (int): number of parallel heads
       model_dim (int): the dimension of keys/values/queries,
           must be divisible by head_count
       dropout (float): dropout parameter
    """

    def __init__(self, head_count, model_dim, dropout=0.1, use_final_linear=True):
        assert model_dim % head_count == 0
        self.dim_per_head = model_dim // head_count
        self.model_dim = model_dim

        super(MultiHeadedAttention, self).__init__()
        # 头数
        self.head_count = head_count
        # Q, K, V线性映射, 维度扩张到head_count
        self.linear_keys = nn.Linear(model_dim, head_count * self.dim_per_head)
        self.linear_values = nn.Linear(model_dim, head_count * self.dim_per_head)
        self.linear_query = nn.Linear(model_dim, head_count * self.dim_per_head)
        self.softmax = nn.Softmax(dim=-1)
        self.dropout = nn.Dropout(dropout)
        self.use_final_linear = use_final_linear
        if self.use_final_linear:
            self.final_linear = nn.Linear(model_dim, model_dim)

    def forward(self, key, value, query, mask=None):
        """
        Compute the context vector and the attention vectors.

        Args:
           key (`FloatTensor`): set of `key_len`
                key vectors `[batch, key_len, dim]`
           value (`FloatTensor`): set of `key_len`
                value vectors `[batch, key_len, dim]`
           query (`FloatTensor`): set of `query_len`
                 query vectors  `[batch, query_len, dim]`
           mask: binary mask indicating which keys have
                 non-zero attention `[batch, query_len, key_len]`
        Returns:
           (`FloatTensor`, `FloatTensor`) :

           * output context vectors `[batch, query_len, dim]`
           * one of the attention vectors `[batch, query_len, key_len]`
        """

        batch_size = key.size(0)
        dim_per_head = self.dim_per_head
        head_count = self.head_count
        key_len = key.size(1)
        query_len = query.size(1)

        def shape(x):
            """  projection, 将最后一维平分成head_count
            输入X为QKV中的一个，维度：[batch_size, seq_length, embedding_dim]
            输出的维度经过reshape和转置：[batch_size, num_heads, seq_length, embedding_dim / num_heads]
            """
            return x.view(batch_size, -1, head_count, dim_per_head).transpose(1, 2)

        def unshape(x):
            """  compute context """
            return x.transpose(1, 2).contiguous() \
                .view(batch_size, -1, head_count * dim_per_head)

        # 1) Q,K,V 维度映射
        # Q, K, V的维度为[batch_size, seq_leng, num_heads * embedding_dim]
        key = self.linear_keys(key)
        value = self.linear_values(value)
        query = self.linear_query(query)
        # 把QKV分割成num_heads份，把维度转换为[batch_size, num_heads, seq_length, embedding_dim / num_heads]
        key = shape(key)
        value = shape(value)
        query = shape(query)

        # 2) Calculate and scale scores.
        query = query / math.sqrt(dim_per_head)  # 除以K的dimension, 开平方根以归一为标准正态分布
        scores = torch.matmul(query, key.transpose(2, 3))  # [batch_size, num_heads, seq_length, seq_length]

        if mask is not None:  # Apply the attention mask
            mask = mask.unsqueeze(1).expand_as(scores)
            scores = scores.masked_fill(mask, -1e18)

        # 3) Apply attention dropout and compute context vectors.
        attn = self.softmax(scores)  # softmax归一化，得到注意力矩阵
        drop_attn = self.dropout(attn)  # (batch_size, num_heads, seq_length, seq_length)

        if self.use_final_linear:
            # 用注意力矩阵加权V, (batch_size, num_heads, seq_length, depth_v)
            context = torch.matmul(drop_attn, value)
            context = unshape(context)  # [bs, seq_len,dim]
            output = self.final_linear(context)  # 最后一层
            return output
        else:
            # 用注意力矩阵加权V, (batch_size, num_heads, seq_length, depth_v)
            context = torch.matmul(drop_attn, value)
            context = unshape(context)  # [bs, seq_len,dim]
            return context
