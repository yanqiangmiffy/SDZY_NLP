import torch
import torch.nn as nn
from pytorch_pretrained_bert import BertModel, BertConfig
from torch.nn.init import xavier_uniform_
from src.models.encoder import TransformerInterEncoder, Classifier, RNNEncoder
from src.models.optimizers import Optimizer
from transformers import BertTokenizer, AlbertModel


def build_optim(args, model, checkpoint):
    """ Build optimizer """
    saved_optimizer_state_dict = None

    if args.train_from != '':
        optim = checkpoint['optim']
        saved_optimizer_state_dict = optim.optimizer.state_dict()
    else:
        optim = Optimizer(
            args.optim, args.lr, args.max_grad_norm,
            beta1=args.beta1, beta2=args.beta2,
            decay_method=args.decay_method,
            warmup_steps=args.warmup_steps)

    optim.set_parameters(list(model.named_parameters()))

    # 可以加载训练好的optimizer
    if args.train_from != '':
        optim.optimizer.load_state_dict(saved_optimizer_state_dict)
        if args.visible_gpus != '-1':
            for state in optim.optimizer.state.values():
                for k, v in state.items():
                    if torch.is_tensor(v):
                        state[k] = v.cuda()

        if (optim.method == 'adam') and (len(optim.optimizer.state) < 1):
            raise RuntimeError(
                "Error: loaded Adam optimizer from existing model" +
                " but optimizer state is empty")

    return optim


class Bert(nn.Module):
    def __init__(self, load_pretrained_bert, bert_config):
        super(Bert, self).__init__()
        if load_pretrained_bert:
            path = '/Users/himon/resource/model_hub/albert_chinese_tiny/'
            self.model = AlbertModel.from_pretrained(path)

        else:
            self.model = BertModel(bert_config)

    def forward(self, x, segs, mask):
        encoded_layers, _ = self.model(x, segs, attention_mask=mask)
        top_vec = encoded_layers[-1]
        return top_vec


class Summarizer(nn.Module):
    def __init__(self, args, device, load_pretrained_bert=True, bert_config=None):
        super(Summarizer, self).__init__()
        self.args = args
        self.device = device
        self.bert = Bert(load_pretrained_bert=load_pretrained_bert, bert_config=bert_config)  # Bert 编码器
        if (args.encoder == 'classifier'):
            self.encoder = Classifier(self.bert.model.config.hidden_size)
        elif (args.encoder == 'transformer'):
            self.encoder = TransformerInterEncoder(self.bert.model.config.hidden_size, args.ff_size, args.heads,
                                                   args.dropout, args.inter_layers)
        elif (args.encoder == 'rnn'):
            self.encoder = RNNEncoder(bidirectional=False, num_layers=1,
                                      input_size=self.bert.model.config.hidden_size, hidden_size=args.rnn_size,
                                      dropout=args.dropout)
        elif (args.encoder == 'baseline'):
            bert_config = BertConfig(self.bert.model.config.vocab_size, hidden_size=args.hidden_size,
                                     num_hidden_layers=6, num_attention_heads=8, intermediate_size=args.ff_size)
            self.bert.model = BertModel(bert_config)
            self.encoder = Classifier(self.bert.model.config.hidden_size)

        if args.param_init != 0.0:  # nn.init 模块有一个 uniform_ 方法，它接收一个张量并使用均匀分布的值对其进行初始化。两者都是一样的，第一个是使用成员函数，第二个是使用通用实用程序。
            for p in self.encoder.parameters():  # 每个张量都有一个 uniform_ 方法，该方法使用均匀分布中的值对其进行初始化
                p.data.uniform_(-args.param_init, args.param_init)  # 均匀分布初始化, 使值服从均匀分布
        if args.param_init_glorot:
            for p in self.encoder.parameters():
                if p.dim() > 1:  # pytorch在torch.nn.init中提供了常用的初始化方法函数,其他的
                    xavier_uniform_(p)  # 权值初始化: Xavier初始化方法公式推导是从“方差一致性”出发，初始化的分布有均匀分布和正态分布两种。xavier_uniform_是均匀分布.

        self.to(device)

    def load_cp(self, pt):
        self.load_state_dict(pt['model'], strict=True)

    def forward(self, x, segs, clss, mask, mask_cls):
        """

        Args:
            x: [bs, max_len]
            segs:[bs, max_len]
            clss: [bs, max_sent_len], [cls]位置坐标
            mask: [bs, max_len]
            mask_cls: [bs, max_sent_len]，mask向量
        Returns:
        """
        top_vec = self.bert(x, segs, mask)  # [bs, max_len, hidden_size]
        sents_vec = top_vec[torch.arange(top_vec.size(0)).unsqueeze(1), clss]  # 取出所有句子表示[bs, clss_len, hidden_dim]
        sents_vec = sents_vec * mask_cls[:, :, None].float()  # [bs, clss_len, hidden_size]
        sent_scores = self.encoder(sents_vec, mask_cls).squeeze(-1)  # [bs, clss_len], 每个句子的分类
        return sent_scores, mask_cls
